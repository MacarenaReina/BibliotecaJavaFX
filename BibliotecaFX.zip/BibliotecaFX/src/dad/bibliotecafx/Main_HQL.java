package dad.bibliotecafx;

import org.hibernate.Session;

import dad.bibliotecafx.utils.HibernateUtil;

public class Main_HQL {

	public static void main(String[] args) {
		Session sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();
		sesion.getTransaction().commit();

		sesion.close();
	}
}
