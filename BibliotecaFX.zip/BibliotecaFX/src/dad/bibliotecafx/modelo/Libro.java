package dad.bibliotecafx.modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@SuppressWarnings("serial")
@Entity
public class Libro implements Serializable {
	
	@Id
	@GeneratedValue
	private Long codigo;
	@Column(columnDefinition="VARCHAR(200)")
	private String titulo;
	
	@OneToOne(cascade={CascadeType.PERSIST,CascadeType.REMOVE})
	@JoinColumn(name="editorial")
	private Editorial editorial;
	
	@OneToMany(fetch=FetchType.LAZY, mappedBy="autores")
	private List<Autor_Libro> autores = new ArrayList<Autor_Libro>();

	@OneToMany
	@JoinColumn(name="prestamo")
	private List<Prestamo> prestamo = new ArrayList<Prestamo>();
	
	
	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public Editorial getEditorial() {
		return editorial;
	}

	public void setEditorial(Editorial editorial) {
		this.editorial = editorial;
	}

	public List<Autor_Libro> getAutores() {
		return autores;
	}

	public void setAutores(List<Autor_Libro> autores) {
		this.autores = autores;
	}

	public List<Prestamo> getPrestamo() {
		return prestamo;
	}

	public void setPrestamo(List<Prestamo> prestamo) {
		this.prestamo = prestamo;
	}
	
}
