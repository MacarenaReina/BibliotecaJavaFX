package dad.bibliotecafx.modelo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@SuppressWarnings("serial")
@Entity
public class Rol_Usuario implements Serializable {
	
	@Id
	@ManyToOne
	@JoinColumn(name="permiso")
	private Rol permiso;
	
	@Id
	@ManyToOne
	@JoinColumn(name="usuario")
	private Usuario usuario;
	
	@Column(columnDefinition="BOOLEAN", name="activado")
	private Boolean activado;

	public Rol getPermiso() {
		return permiso;
	}

	public void setPermiso(Rol permiso) {
		this.permiso = permiso;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public Boolean getActivado() {
		return activado;
	}

	public void setActivado(Boolean activado) {
		this.activado = activado;
	}

}
