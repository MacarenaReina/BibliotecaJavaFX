package dad.bibliotecafx.modelo;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@SuppressWarnings("serial")
@Entity
public class Autor_Libro implements Serializable  {
	@Id
	@ManyToOne
	@JoinColumn(name="autores")
	private Autor autores;
	
	@Id
	@ManyToOne
	@JoinColumn(name="libros")
	private Libro libros;
	
	public Autor getAutor() {
		return autores;
	}
	public void setAutor(Autor autor) {
		this.autores = autor;
	}
	public Libro getLibro() {
		return libros;
	}
	public void setLibro(Libro libro) {
		this.libros = libro;
	}
	
}
