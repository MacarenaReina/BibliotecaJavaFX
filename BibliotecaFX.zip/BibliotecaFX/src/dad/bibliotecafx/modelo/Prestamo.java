package dad.bibliotecafx.modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;


@SuppressWarnings("serial")
@Entity
public class Prestamo implements Serializable {
	@Id
	@GeneratedValue
	private Long codigo;
	
	@Id
	@OneToMany(fetch=FetchType.LAZY, mappedBy="prestamo")
	private List<Libro> libro = new ArrayList<Libro>();
	
	@ManyToOne
	@JoinColumn(name="usuario")
	private Usuario usuario;
	
	@Column(columnDefinition="DATE")
	private Date fechaPrestamo;
	
	@Column(columnDefinition="DATE")
	private Date fechaDevolucion;
	
	public Long getCodigo() {
		return codigo;
	}
	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}
	public List<Libro> getRol_usuario() {
		return libro;
	}
	public void setRol_usuario(List<Libro> libro) {
		this.libro = libro;
	}
	public Usuario getUsuario() {
		return usuario;
	}
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
	public Date getFechaPrestamo() {
		return fechaPrestamo;
	}
	public void setFechaPrestamo(Date fechaPrestamo) {
		this.fechaPrestamo = fechaPrestamo;
	}
	public Date getFechaDevolucion() {
		return fechaDevolucion;
	}
	public void setFechaDevolucion(Date fechaDevolucion) {
		this.fechaDevolucion = fechaDevolucion;
	}
}
