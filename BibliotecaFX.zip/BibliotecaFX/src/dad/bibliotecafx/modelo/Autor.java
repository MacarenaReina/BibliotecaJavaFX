package dad.bibliotecafx.modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@SuppressWarnings("serial")
@Entity
public class Autor implements Serializable {
	@Id
	@GeneratedValue
	private Long codigo;
	
	@Column(columnDefinition="VARCHAR(100)")
	private String nombre;
	
	@OneToMany(fetch=FetchType.LAZY, mappedBy="libros")
	private List<Autor_Libro> libros = new ArrayList<Autor_Libro>();

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public List<Autor_Libro> getLibros() {
		return libros;
	}

	public void setLibros(List<Autor_Libro> libros) {
		this.libros = libros;
	}

}
	
