package dad.bibliotecafx.modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@SuppressWarnings("serial")
@Entity
public class Rol implements Serializable {
	@Id
	@GeneratedValue
	private Long codigo;
	@Column(columnDefinition="VARCHAR(30)")
	private String tipo;	
	@OneToMany(fetch=FetchType.LAZY, mappedBy="permiso")
	private List<Rol_Usuario> usuario = new ArrayList<Rol_Usuario>();
		
	public List<Rol_Usuario> getRol_usuario() {
		return usuario;
	}
	public void setRol_usuario(List<Rol_Usuario> rol_usuario) {
		this.usuario = rol_usuario;
	}
	public Long getCodigo() {
		return codigo;
	}
	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
}
