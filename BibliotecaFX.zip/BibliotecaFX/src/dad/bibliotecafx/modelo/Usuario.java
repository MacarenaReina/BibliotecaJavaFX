package dad.bibliotecafx.modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@SuppressWarnings("serial")
@Entity
public class Usuario implements Serializable {
	@Id
	@GeneratedValue
	private Long codigo;
	@Column(columnDefinition="VARCHAR 100")
	private String nombre;
	@Column(columnDefinition="VARCHAR(20)")
	private String usuario;
	@Column(columnDefinition="VARCHAR(20)")
	private String password;
	@OneToMany(fetch=FetchType.LAZY, mappedBy="usuario")
	private List<Rol_Usuario> rol = new ArrayList<Rol_Usuario>();
	
	@OneToMany(fetch=FetchType.LAZY, mappedBy="usuario")
	private List<Prestamo> prestamos = new ArrayList<Prestamo>();
	
	public Long getCodigo() {
		return codigo;
	}
	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public List<Rol_Usuario> getRol_usuario() {
		return rol;
	}
	public void setRol_usuario(List<Rol_Usuario> rol_usuario) {
		this.rol = rol_usuario;
	}
	

}
