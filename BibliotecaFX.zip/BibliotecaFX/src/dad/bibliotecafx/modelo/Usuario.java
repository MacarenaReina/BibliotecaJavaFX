package dad.bibliotecafx.modelo;

public class Usuario {
	Integer codigo;
	String nombre;
	String usuario;
	String password;
	Boolean activado;
	Rol permiso;
	
	public Integer getCodigo() {
		return codigo;
	}
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Boolean getActivado() {
		return activado;
	}
	public void setActivado(Boolean activado) {
		this.activado = activado;
	}
	public Rol getPermiso() {
		return permiso;
	}
	public void setPermiso(Rol permiso) {
		this.permiso = permiso;
	}
}
