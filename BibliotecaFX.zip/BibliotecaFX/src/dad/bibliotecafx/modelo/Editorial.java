package dad.bibliotecafx.modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@SuppressWarnings("serial")
@Entity
public class Editorial implements Serializable {
	@Id
	@GeneratedValue
	private Long codigo;
	
	@Column(columnDefinition="VARCHAR(50)")
	private String nombre;
	
	private Integer anioPublicacion;
	
	@OneToMany(fetch=FetchType.LAZY, mappedBy="editorial")	
	private List<Libro> libros = new ArrayList<Libro>();
	
	public Long getCodigo() {
		return codigo;
	}
	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public Integer getAnioPublicacion() {
		return anioPublicacion;
	}
	public void setAnioPublicacion(Integer anioPublicacion) {
		this.anioPublicacion = anioPublicacion;
	}
	public List<Libro> getLibros() {
		return libros;
	}
	public void setLibros(List<Libro> libros) {
		this.libros = libros;
	}
	
}
