package dad.bibliotecafx.modelo;

public class Editorial {
	Integer codigo;
	String nombre;
	Integer anioPublicacion;
	
	public Integer getCodigo() {
		return codigo;
	}
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public Integer getAnioPublicacion() {
		return anioPublicacion;
	}
	public void setAnioPublicacion(Integer anioPublicacion) {
		this.anioPublicacion = anioPublicacion;
	}	
}
