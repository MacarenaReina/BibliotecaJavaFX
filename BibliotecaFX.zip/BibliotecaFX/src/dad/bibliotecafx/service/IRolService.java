package dad.bibliotecafx.service;

import java.util.List;

import dad.bibliotecafx.modelo.Rol;
import dad.bibliotecafx.modelo.Rol_Usuario;

public interface IRolService {
	public List<Rol> listarRoles() throws ServiceException;
	public void crearRol(Rol rol) throws ServiceException;
	public void actualizarRol(Rol rol) throws ServiceException;
	public void eliminarRol(Rol rol) throws ServiceException;
	public void asignarRol(Rol_Usuario ru) throws ServiceException;
	public void actualizarRolUsuario(Rol_Usuario ru) throws ServiceException;
	public void eliminarRolUsuario(Rol_Usuario ru) throws ServiceException;
}
