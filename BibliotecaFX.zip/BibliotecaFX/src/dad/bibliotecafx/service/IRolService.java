package dad.bibliotecafx.service;

import java.util.List;

import dad.bibliotecafx.modelo.Rol;
import dad.bibliotecafx.modelo.RolUsuario;

public interface IRolService {
	public List<Rol> listarRoles() throws ServiceException;
	public void crearRol(Rol rol) throws ServiceException;
	public void actualizarRol(Rol rol) throws ServiceException;
	public void eliminarRol(Rol rol) throws ServiceException;
	public void asignarRol(RolUsuario rolUsuario) throws ServiceException;
	public void actualizarRolUsuario(RolUsuario rolUsuario) throws ServiceException;
	public void eliminarRolUsuario(RolUsuario rolUsuario) throws ServiceException;
}
