package dad.bibliotecafx.service;

import java.util.List;

import dad.bibliotecafx.modelo.Rol;
import dad.bibliotecafx.modelo.Usuario;

public interface IRolService {
	public List<Rol> listarRoles() throws ServiceException;
	public void crearRol(Rol rol) throws ServiceException;
	public void actualizarRol(Rol rol) throws ServiceException;
	public void eliminarRol(Integer id) throws ServiceException;
	public void asignarRol(Usuario usuario, Rol rol) throws ServiceException;
	public void actualizarRolUsuario(Usuario usuario, Rol rol) throws ServiceException;
	public void eliminarRolUsuario(Integer id) throws ServiceException;
}
