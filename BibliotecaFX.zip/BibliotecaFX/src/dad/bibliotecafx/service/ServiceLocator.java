package dad.bibliotecafx.service;

import dad.bibliotecafx.service.impl.EditorialService;
import dad.bibliotecafx.service.impl.LibroService;
import dad.bibliotecafx.service.impl.RolService;
import dad.bibliotecafx.service.impl.SancionService;

public class ServiceLocator {
	private static ILibroService libroService;
	private static IEditorialService editorialService;
	private static IRolService rolService;
	private static ISancionService sancionService;
	
	static {
		libroService = new LibroService();
		editorialService = new EditorialService();
		rolService = new RolService();
		sancionService = new SancionService();
	}

	public static ILibroService getLibroService() {
		return libroService;
	}
	
	public static IEditorialService getEditorialService() {
		return editorialService;
	}
	
	public static IRolService getRolService() {
		return rolService;
	}
	
	public static ISancionService getSancionService() {
		return sancionService;
	}
}
