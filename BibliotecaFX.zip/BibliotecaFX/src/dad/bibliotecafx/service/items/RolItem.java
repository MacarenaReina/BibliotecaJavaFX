package dad.bibliotecafx.service.items;

import java.util.ArrayList;
import java.util.List;

import dad.bibliotecafx.modelo.Rol;
import dad.bibliotecafx.modelo.RolUsuario;
import dad.bibliotecafx.service.entidades.RolEntity;
import dad.bibliotecafx.service.entidades.RolUsuarioEntity;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class RolItem {

	public static Rol toModel(RolEntity rolEntity){
		Rol r = new Rol();		
		r.setCodigo(rolEntity.getCodigo());
		r.setTipo(rolEntity.getTipo());
		ObservableList<RolUsuario> rol_usuarioList = FXCollections.observableArrayList(new ArrayList<RolUsuario>());
		for (RolUsuarioEntity rue : rolEntity.getUsuario()) {
			rol_usuarioList.add(RolUsuarioItem.toModel(rue));
		}
		r.setUsuario(rol_usuarioList);		
		return r;
	}
	
	public static RolEntity toEntity(Rol rol){
		RolEntity re = new RolEntity();		
		re.setCodigo(rol.getCodigo());
		re.setTipo(rol.getTipo());
		List<RolUsuarioEntity> ru = new ArrayList<RolUsuarioEntity>();
		for (RolUsuario r : rol.getUsuario()) {
			ru.add(RolUsuarioItem.toEntity(r));			
		}
		re.setUsuario(ru);		
		return re;
	}
	
}
