package dad.bibliotecafx.service.items;

import dad.bibliotecafx.modelo.Sancion;
import dad.bibliotecafx.service.entidades.SancionEntity;

public class SancionItem {

	public static Sancion toModel(SancionEntity sancionEntity){
		Sancion s = new Sancion();		
		s.setFechaAlta(sancionEntity.getFechaAlta());
		s.setFechaFinalizacion(sancionEntity.getFechaFinalizacion());
		s.setLibro(LibroItem.toModel(sancionEntity.getLibro()));
		s.setPrestamo(PrestamoItem.toModel(sancionEntity.getPrestamo()));		
		return s;
	}
	
	
	public static SancionEntity toEntity(Sancion sancion){
		SancionEntity se = new SancionEntity();		
		se.setFechaAlta(sancion.getFechaAlta());
		se.setFechaFinalizacion(sancion.getFechaFinalizacion());
		se.setLibro(LibroItem.toEntity(sancion.getLibro()));
		se.setPrestamo(PrestamoItem.toEntity(sancion.getPrestamo()));
		return se;
	}	
}
