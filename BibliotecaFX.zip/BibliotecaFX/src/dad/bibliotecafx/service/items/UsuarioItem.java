package dad.bibliotecafx.service.items;

import java.util.ArrayList;
import java.util.List;

import dad.bibliotecafx.modelo.Prestamo;
import dad.bibliotecafx.modelo.RolUsuario;
import dad.bibliotecafx.modelo.Usuario;
import dad.bibliotecafx.service.entidades.PrestamoEntity;
import dad.bibliotecafx.service.entidades.RolUsuarioEntity;
import dad.bibliotecafx.service.entidades.UsuarioEntity;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class UsuarioItem {


	public static Usuario toModel(UsuarioEntity usuarioEntity){
		Usuario u = new Usuario();		
		u.setCodigo(usuarioEntity.getCodigo());
		u.setNombre(usuarioEntity.getNombre());
		u.setPassword(usuarioEntity.getPassword());
		u.setUsuario(usuarioEntity.getUsuario());
		ObservableList<RolUsuario> rolList = FXCollections.observableArrayList(new ArrayList<RolUsuario>());
		for (RolUsuarioEntity r : usuarioEntity.getRol()) {
			rolList.add(RolUsuarioItem.toModel(r));
		}		
		u.setRol(rolList);
		ObservableList<Prestamo> prestamoList = FXCollections.observableArrayList();
		for (PrestamoEntity p : usuarioEntity.getPrestamos()) {
			prestamoList.add(PrestamoItem.toModel(p));
		}
		u.setPrestamos(prestamoList);		
		return u;
	}
	
	public static UsuarioEntity toEntity(Usuario usuario){
		UsuarioEntity ue = new UsuarioEntity();		
		ue.setCodigo(usuario.getCodigo());
		ue.setNombre(usuario.getNombre());
		ue.setUsuario(usuario.getUsuario());
		ue.setPassword(usuario.getPassword());
		List<PrestamoEntity> prestamos = new ArrayList<PrestamoEntity>();
		for (Prestamo p : usuario.getPrestamos()) {
			prestamos.add(PrestamoItem.toEntity(p));			
		}
		ue.setPrestamos(prestamos);
		List<RolUsuarioEntity> roles = new ArrayList<RolUsuarioEntity>();
		for (RolUsuario r : usuario.getRol()) {
			roles.add(RolUsuarioItem.toEntity(r));			
		}		
		ue.setRol(roles);
		return ue;
	}
	
}
