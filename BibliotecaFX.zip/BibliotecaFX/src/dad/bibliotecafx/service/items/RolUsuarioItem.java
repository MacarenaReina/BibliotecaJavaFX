package dad.bibliotecafx.service.items;

import dad.bibliotecafx.modelo.RolUsuario;
import dad.bibliotecafx.service.entidades.RolUsuarioEntity;

public class RolUsuarioItem {

	public static RolUsuario toModel(RolUsuarioEntity rolUsuarioEntity){
		RolUsuario ru = new RolUsuario();		
		ru.setActivado(rolUsuarioEntity.getActivado());
		ru.setPermiso(RolItem.toModel(rolUsuarioEntity.getPermiso()));
		ru.setUsuario(UsuarioItem.toModel(rolUsuarioEntity.getUsuario()));		
		return ru;
	}

	
	public static RolUsuarioEntity toEntity(RolUsuario rolUsuario){
		RolUsuarioEntity rue = new RolUsuarioEntity();		
		rue.setActivado(rolUsuario.isActivado());
		rue.setPermiso(RolItem.toEntity(rolUsuario.getPermiso()));
		rue.setUsuario(UsuarioItem.toEntity(rolUsuario.getUsuario()));		
		return rue;
	}	
	
}
