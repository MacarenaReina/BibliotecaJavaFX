package dad.bibliotecafx.service.items;

import java.util.HashSet;

import dad.bibliotecafx.modelo.Autor;
import dad.bibliotecafx.modelo.Libro;
import dad.bibliotecafx.service.entidades.AutorEntity;
import dad.bibliotecafx.service.entidades.LibroEntity;
import javafx.collections.FXCollections;
import javafx.collections.ObservableSet;

public class LibroItem {

	public static Libro toModel(LibroEntity libroEntity) {
		Libro l = new Libro();		
		l.setEditorial(EditorialItem.toModel(libroEntity.getEditorial()));
		l.setISBN(libroEntity.getISBN());
		l.setTitulo(libroEntity.getTitulo());
		l.setAnioPublicacion(libroEntity.getAnioPublicacion());
		ObservableSet<Autor> autoresList = FXCollections.observableSet(new HashSet<Autor>());
		for (AutorEntity a : libroEntity.getAutores()) {
			autoresList.add(AutorItem.toModel(a));
		}		
		l.setAutores(autoresList);
		return l;
		
	}
	
	public static LibroEntity toEntity(Libro libro){
		LibroEntity le = new LibroEntity();		
		le.setEditorial(EditorialItem.toEntity(libro.getEditorial()));
		le.setAnioPublicacion(libro.getAnioPublicacion());
		le.setISBN(libro.getISBN());
		le.setTitulo(libro.getTitulo());		
		ObservableSet<AutorEntity> autorList = FXCollections.observableSet(new HashSet<AutorEntity>());
		for (Autor a : libro.getAutores()) {
			autorList.add(AutorItem.toEntity(a));
		}			
		le.setAutores(autorList);
		return le;
	}
	
}
