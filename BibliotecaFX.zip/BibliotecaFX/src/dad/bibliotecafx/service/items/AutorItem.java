package dad.bibliotecafx.service.items;

import dad.bibliotecafx.modelo.Autor;
import dad.bibliotecafx.service.entidades.AutorEntity;

public class AutorItem {

	public static Autor toModel(AutorEntity autorEntity) {
		Autor autor = new Autor();
		autor.setCodigo(autorEntity.getCodigo());
		autor.setNombre(autorEntity.getNombre());
		return autor;
	}
	
	public static AutorEntity toEntity(Autor autor){
		AutorEntity ae = new AutorEntity();			
		ae.setCodigo(autor.getCodigo());
		ae.setNombre(autor.getNombre());		
		return ae;
	}
	
}
