package dad.bibliotecafx.service.items;

import java.util.ArrayList;
import java.util.List;

import dad.bibliotecafx.modelo.Libro;
import dad.bibliotecafx.modelo.Prestamo;
import dad.bibliotecafx.service.entidades.LibroEntity;
import dad.bibliotecafx.service.entidades.PrestamoEntity;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class PrestamoItem {
	
	public static Prestamo toModel(PrestamoEntity prestamoEntity){
		Prestamo p = new Prestamo();
		p.setCodigo(prestamoEntity.getCodigo());
		p.setFechaDevolucion(prestamoEntity.getFechaDevolucion());
		p.setFechaPrestamo(prestamoEntity.getFechaPrestamo());
		p.setUsuario(UsuarioItem.toModel(prestamoEntity.getUsuario()));
		ObservableList<Libro> librosList = FXCollections.observableArrayList(new ArrayList<Libro>());
		for (LibroEntity l : prestamoEntity.getLibro()) {
			librosList.add(LibroItem.toModel(l));
		}	
		p.setLibro(librosList);
		return p;
	}
	
	public static PrestamoEntity toEntity(Prestamo prestamo){
		PrestamoEntity pe = new PrestamoEntity();			
		pe.setCodigo(prestamo.getCodigo());
		pe.setFechaDevolucion(prestamo.getFechaDevolucion());
		pe.setFechaPrestamo(prestamo.getFechaPrestamo());
		pe.setUsuario(UsuarioItem.toEntity(prestamo.getUsuario()));
		List<LibroEntity> libros = new ArrayList<LibroEntity>();
		for (Libro l : prestamo.getLibro()) {
			libros.add(LibroItem.toEntity(l));			
		}		
		pe.setLibro(libros);		
		return pe;
	}	
	
}
