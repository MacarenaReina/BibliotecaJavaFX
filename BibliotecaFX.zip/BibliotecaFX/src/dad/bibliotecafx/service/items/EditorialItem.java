package dad.bibliotecafx.service.items;

import java.util.ArrayList;
import java.util.List;

import dad.bibliotecafx.modelo.Editorial;
import dad.bibliotecafx.modelo.Libro;
import dad.bibliotecafx.service.entidades.EditorialEntity;
import dad.bibliotecafx.service.entidades.LibroEntity;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class EditorialItem {

	public static Editorial toModel(EditorialEntity editorialEntity) {
		Editorial e = new Editorial();		
		e.setCodigo(editorialEntity.getCodigo());
		e.setNombre(editorialEntity.getNombre());
		ObservableList<Libro> librosList = FXCollections.observableArrayList(new ArrayList<Libro>());
		for (LibroEntity l : editorialEntity.getLibros()) {
			librosList.add(LibroItem.toModel(l));
		}	
		e.setLibros(librosList);
		return e;		
	}
	
	public static EditorialEntity toEntity(Editorial editorial){
		EditorialEntity ee = new EditorialEntity();
		ee.setCodigo(editorial.getCodigo());
		ee.setNombre(editorial.getNombre());
		
		List<LibroEntity> libros = new ArrayList<LibroEntity>();
		for (Libro l : editorial.getLibros()) {
			libros.add(LibroItem.toEntity(l));			
		}		
		ee.setLibros(libros);		
		return ee;
	}
	
}
