package dad.bibliotecafx.service;

import java.util.List;

import dad.bibliotecafx.modelo.Prestamo;

public interface IPrestamoService {
	public List<Prestamo> listarPrestamos() throws ServiceException;
	public void crearUsuario(Prestamo prestamo) throws ServiceException;
	public void actualizarUsuario(Prestamo prestamo) throws ServiceException;
	public void eliminarUsuario(Prestamo prestamo) throws ServiceException;
}
