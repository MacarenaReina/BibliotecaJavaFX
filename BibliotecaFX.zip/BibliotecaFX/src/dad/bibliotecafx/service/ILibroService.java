package dad.bibliotecafx.service;

import java.util.List;
import dad.bibliotecafx.modelo.Libro;

public interface ILibroService {
	public List<Libro> listarLibros() throws ServiceException;
	public void crearLibro(Libro libro) throws ServiceException;
	public void actualizarLibro(Libro libro) throws ServiceException;
	public void eliminarLibro(Integer id) throws ServiceException;
}
