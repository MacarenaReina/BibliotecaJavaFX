package dad.bibliotecafx.service;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import dad.bibliotecafx.modelo.Usuario;
import dad.bibliotecafx.utils.HibernateUtil;

public class UsuarioService implements IUsuarioService {
	
	private Session sesion;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Usuario> listarUsuarios() throws ServiceException {
		sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();		
		Query consultaUsuarios = sesion.createQuery("FROM Usuario");
		List<Usuario> usuariosList = consultaUsuarios.list();
		sesion.getTransaction().commit();
		sesion.close();		
		return usuariosList;		
	}

	@Override
	public void crearUsuario(Usuario usuario) throws ServiceException {
		sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();	
		sesion.save(usuario);	
		sesion.getTransaction().commit();
		sesion.close();	
	}

	@Override
	public void actualizarUsuario(Usuario usuario) throws ServiceException {
		sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();	
		sesion.update(usuario);
		sesion.getTransaction().commit();
		sesion.close();	
	}

	@Override
	public void eliminarUsuario(Usuario usuario) throws ServiceException {
		sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();	
		sesion.delete(usuario);
		sesion.getTransaction().commit();
		sesion.close();	
	}

}
