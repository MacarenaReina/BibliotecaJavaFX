package dad.bibliotecafx.service;

import java.util.List;

import dad.bibliotecafx.modelo.Usuario;

public interface IUsuarioService {
	public List<Usuario> listarUsuarios() throws ServiceException;
	public void crearUsuario(Usuario usuario) throws ServiceException;
	public void actualizarUsuario(Usuario usuario) throws ServiceException;
	public void eliminarUsuario(Usuario usuario) throws ServiceException;
}
