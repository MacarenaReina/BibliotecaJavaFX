package dad.bibliotecafx.service;

import java.util.List;

import dad.bibliotecafx.modelo.Sancion;

public interface ISancionService {
	public List<Sancion> listarSanciones() throws ServiceException;
	public void crearSancion(Sancion sancion) throws ServiceException;
	public void actualizarSancion(Sancion sancion) throws ServiceException;
	public void eliminarSancion(Sancion sancion) throws ServiceException;
}
