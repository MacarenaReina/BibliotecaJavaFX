package dad.bibliotecafx.service;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import dad.bibliotecafx.modelo.Prestamo;
import dad.bibliotecafx.utils.HibernateUtil;

public class PrestamoService implements IPrestamoService {
	
	private Session sesion;

	@SuppressWarnings("unchecked")
	@Override
	public List<Prestamo> listarPrestamos() throws ServiceException {
		sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();		
		Query consultaPrestamos = sesion.createQuery("FROM Prestamo");
		List<Prestamo> prestamosList = consultaPrestamos.list();
		sesion.getTransaction().commit();
		sesion.close();		
		return prestamosList;
	}

	@Override
	public void crearUsuario(Prestamo prestamo) throws ServiceException {
		sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();	
		sesion.save(prestamo);	
		sesion.getTransaction().commit();
		sesion.close();
	}

	@Override
	public void actualizarUsuario(Prestamo prestamo) throws ServiceException {
		sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();	
		sesion.update(prestamo);
		sesion.getTransaction().commit();
		sesion.close();
	}

	@Override
	public void eliminarUsuario(Prestamo prestamo) throws ServiceException {
		sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();	
		sesion.delete(prestamo);
		sesion.getTransaction().commit();
		sesion.close();
	}

}
