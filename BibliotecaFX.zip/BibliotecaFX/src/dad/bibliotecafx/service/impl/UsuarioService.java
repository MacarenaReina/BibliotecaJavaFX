package dad.bibliotecafx.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;

import dad.bibliotecafx.db.DataBase;
import dad.bibliotecafx.modelo.Usuario;
import dad.bibliotecafx.service.IUsuarioService;
import dad.bibliotecafx.service.ServiceException;
import dad.bibliotecafx.service.entidades.UsuarioEntity;
import dad.bibliotecafx.service.items.UsuarioItem;

public class UsuarioService implements IUsuarioService {


	@SuppressWarnings("unchecked")
	@Override
	public List<Usuario> listarTodosUsuarios() throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();
		Query consultaUsuarios = DataBase.getSession().createQuery("FROM Usuario");
		List<UsuarioEntity> usuariosList = consultaUsuarios.list();
		
		List<Usuario> usuarios = new ArrayList<Usuario>();
		for (UsuarioEntity u : usuariosList) {
			usuarios.add(UsuarioItem.toModel(u));
		}		
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
		return usuarios;
	}

	@Override
	public void crearUsuario(Usuario usuario) throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();
		
		DataBase.getSession().save(UsuarioItem.toEntity(usuario));
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
	}

	@Override
	public void actualizarUsuario(Usuario usuario) throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();
		
		DataBase.getSession().update(DataBase.getSession().merge(UsuarioItem.toEntity(usuario)));
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
	}

	@Override
	public void eliminarUsuario(Usuario usuario) throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();
		
		DataBase.getSession().delete(UsuarioItem.toEntity(usuario));
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Usuario> listarUsuariosLectores() throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();
		Query consultaUsuarios = DataBase.getSession()
				.createQuery(
						"FROM Usuario AS u INNER JOIN Rol_Usuario AS ru ON u.codigo = ru.usuario.codigo WHERE ru.permiso.tipo=:tipo")
				.setString("tipo", "Lector");
		List<UsuarioEntity> usuariosList = consultaUsuarios.list();
		
		List<Usuario> usuarios = new ArrayList<Usuario>();
		for (UsuarioEntity u : usuariosList) {
			usuarios.add(UsuarioItem.toModel(u));
		}
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
		return usuarios;
	}

}
