package dad.bibliotecafx.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;

import dad.bibliotecafx.db.DataBase;
import dad.bibliotecafx.modelo.Autor;
import dad.bibliotecafx.service.IAutorService;
import dad.bibliotecafx.service.ServiceException;
import dad.bibliotecafx.service.entidades.AutorEntity;
import dad.bibliotecafx.service.items.AutorItem;

public class AutorService implements IAutorService {

	@SuppressWarnings("unchecked")
	@Override
	public List<Autor> listarAutores() throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();		
		Query consultaAutores = DataBase.getSession().createQuery("FROM Autor");
		List<AutorEntity> autorList = consultaAutores.list();
		
		List<Autor> autores = new ArrayList<Autor>();
		
		for (AutorEntity a : autorList) {
			autores.add(AutorItem.toModel(a));
		}
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
		return autores;
	}

	@Override
	public void crearAutor(Autor autor) throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();	
		
		DataBase.getSession().save(AutorItem.toEntity(autor));	
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
	}

	@Override
	public void actualizarAutor(Autor autor) throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();	
		
		DataBase.getSession().update(DataBase.getSession().merge(AutorItem.toEntity(autor)));
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
	}

	@Override
	public void eliminarAutor(Autor autor) throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();	
		
		DataBase.getSession().delete(AutorItem.toEntity(autor));
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
	}

}
