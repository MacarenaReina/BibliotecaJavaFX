package dad.bibliotecafx.service.impl;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.Query;

import dad.bibliotecafx.db.DataBase;
import dad.bibliotecafx.modelo.Libro;
import dad.bibliotecafx.service.ILibroService;
import dad.bibliotecafx.service.ServiceException;
import dad.bibliotecafx.service.entidades.LibroEntity;
import dad.bibliotecafx.service.items.LibroItem;

public class LibroService implements ILibroService {

	@SuppressWarnings("unchecked")
	@Override
	public List<Libro> listarLibros() throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();		
		Query consultaLibros = DataBase.getSession().createQuery("FROM Libro");
		List<LibroEntity> librosList = consultaLibros.list();

		List<Libro> libros = new ArrayList<Libro>();		
		for (LibroEntity l : librosList) {
			libros.add(LibroItem.toModel(l));
		}
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
		return libros;
	}

	@Override
	public void crearLibro(Libro libro) throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();	
		
		DataBase.getSession().save(LibroItem.toEntity(libro));	
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
	}

	@Override
	public void actualizarLibro(Libro libro) throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();
		
		DataBase.getSession().update(DataBase.getSession().merge(LibroItem.toEntity(libro)));
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
	}

	@Override
	public void eliminarLibro(Libro libro) throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();	
		
		DataBase.getSession().delete(LibroItem.toEntity(libro));
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
	}	
}
