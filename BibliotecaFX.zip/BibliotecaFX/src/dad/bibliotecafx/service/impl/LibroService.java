package dad.bibliotecafx.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dad.bibliotecafx.modelo.Autor;
import dad.bibliotecafx.modelo.Editorial;
import dad.bibliotecafx.modelo.Libro;
import dad.bibliotecafx.service.ILibroService;
import dad.bibliotecafx.service.ServiceException;
import dad.bibliotecafx.db.DataBase;

public class LibroService implements ILibroService {
	Connection conn;
	public LibroService(){
		conn = DataBase.connect();
	}

	@Override
	public List<Libro> listarLibros() throws ServiceException {
		List<Libro> librosList = new ArrayList<Libro>();
		
		String cons = "SELECT el.Cod_Editorial, al.Cod_Autor, l.Cod_Libro, l.Titulo FROM editorial_libro AS el "
				+ "INNER JOIN libro AS l ON el.Cod_Libro = l.Cod_Libro "
				+ "INNER JOIN autor_libro AS al ON l.Cod_Libro = al.Cod_Libro";
		
		try {
			PreparedStatement consulta = conn.prepareStatement(cons);
			
			ResultSet resultado;
			resultado = consulta.executeQuery();
			
			while (resultado.next()) {
				Libro l = new Libro();
				Autor a = new Autor();
				Editorial e = new Editorial();
				
				a.setCodigo(resultado.getInt("Cod_Autor"));
				e.setCodigo(resultado.getInt("Cod_Editorial"));
							
				l.setAutor(a);
				l.setEditorial(e);
				l.setCodigo(resultado.getInt("Cod_Libro"));
				l.setTitulo(resultado.getString("Titulo"));

				librosList.add(l);
			}
			consulta.close();			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new ServiceException("No se ha podido realizar la consulta de libros.", e);
		}
		
		return librosList;
	}

	@Override
	public void crearLibro(Libro libro) throws ServiceException {
		String insLibro = "INSERT INTO libro (Titulo) VALUES (?)";
		String insEdit = "INSERT INTO editorial_libro (Cod_Libro, Cod_Editorial, Anio_Publicacion) VALUES (?,?,?)";
		String insAutor = "INSERT INTO autor_libro (Cod_Autor, Cod_Libro) VALUES (?,?)";
		
		try {
			PreparedStatement insercionLibro = conn.prepareStatement(insLibro);
			insercionLibro.setString(1, libro.getTitulo());
			int codLibro = insercionLibro.executeUpdate();
			
			PreparedStatement insercionEdit = conn.prepareStatement(insEdit);
			insercionEdit.setInt(1, codLibro);
			insercionEdit.setInt(2, libro.getEditorial().getCodigo());
			insercionEdit.setInt(3, libro.getEditorial().getAnioPublicacion());			
			insercionEdit.executeUpdate();
			
			PreparedStatement insercionAutor = conn.prepareStatement(insAutor);
			insercionAutor.setInt(1, libro.getAutor().getCodigo());
			insercionAutor.setInt(2, codLibro);
			insercionAutor.executeUpdate();			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new ServiceException("No se ha podido insertar el libro.", e);
		}
		
	}

	@Override
	public void actualizarLibro(Libro libro) throws ServiceException {
		String updLibro = "UPDATE Libro SET Titulo = ? WHERE Cod_Libro = ?";
		String updEdit = "UPDATE editorial_libro SET Cod_Editorial = ?, Anio_Publicacion = ? WHERE Cod_Libro = ?";
		String updAutor = "UPDATE autor_libro SET Cod_Autor = ? WHERE Cod_Libro = ?";
		
		try {
			PreparedStatement updateLibro = conn.prepareStatement(updLibro);
			updateLibro.setString(1, libro.getTitulo());
			updateLibro.setInt(2, libro.getCodigo());
			updateLibro.executeUpdate();
			
			PreparedStatement updateEditorial = conn.prepareStatement(updEdit);
			updateEditorial.setInt(1, libro.getEditorial().getCodigo());
			updateEditorial.setInt(2, libro.getEditorial().getAnioPublicacion());
			updateEditorial.setInt(3, libro.getCodigo());
			updateEditorial.executeUpdate();
			
			PreparedStatement updateAutor = conn.prepareStatement(updAutor);
			updateAutor.setInt(1, libro.getAutor().getCodigo());
			updateAutor.setInt(2, libro.getCodigo());
			updateAutor.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new ServiceException("No se ha podido actualizar el libro.", e);
		}
	}

	@Override
	public void eliminarLibro(Integer id) throws ServiceException {
		String del = "DELETE FROM libro WHERE Cod_Libro = ?";
		try {
			PreparedStatement eliminar = conn.prepareStatement(del);
			eliminar.setInt(1, id);
			eliminar.executeUpdate();			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new ServiceException("No se ha podido eliminar el libro.", e);
		}
	}
	
}
