package dad.bibliotecafx.service.impl;

import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import dad.bibliotecafx.modelo.Libro;
import dad.bibliotecafx.service.ILibroService;
import dad.bibliotecafx.service.ServiceException;
import dad.bibliotecafx.utils.HibernateUtil;

public class LibroService implements ILibroService {
	
	private Session sesion;

	@SuppressWarnings("unchecked")
	@Override
	public List<Libro> listarLibros() throws ServiceException {		
		sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();		
		Query consultaLibros = sesion.createQuery("FROM Libro");
		List<Libro> librosList = consultaLibros.list();
		sesion.getTransaction().commit();
		sesion.close();		
		return librosList;
	}

	@Override
	public void crearLibro(Libro libro) throws ServiceException {
		sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();	
		sesion.save(libro);	
		sesion.getTransaction().commit();
		sesion.close();				
	}

	@Override
	public void actualizarLibro(Libro libro) throws ServiceException {
		sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();	
		sesion.update(libro);
		sesion.getTransaction().commit();
		sesion.close();	
	}

	@Override
	public void eliminarLibro(Libro libro) throws ServiceException {
		sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();	
		sesion.delete(libro);
		sesion.getTransaction().commit();
		sesion.close();	
	}
	
}
