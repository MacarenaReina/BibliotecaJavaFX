package dad.bibliotecafx.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;

import dad.bibliotecafx.db.DataBase;
import dad.bibliotecafx.modelo.Sancion;
import dad.bibliotecafx.service.ISancionService;
import dad.bibliotecafx.service.ServiceException;
import dad.bibliotecafx.service.entidades.SancionEntity;
import dad.bibliotecafx.service.items.SancionItem;

public class SancionService implements ISancionService {

	@SuppressWarnings("unchecked")
	@Override
	public List<Sancion> listarSanciones() throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();		
		Query consultaSanciones = DataBase.getSession().createQuery("FROM Sancion");
		List<SancionEntity> sancionList = consultaSanciones.list();
		
		List<Sancion> sanciones = new ArrayList<Sancion>();
		for (SancionEntity s : sancionList) {
			sanciones.add(SancionItem.toModel(s));
		}
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
		return sanciones;		
	}

	@Override
	public void crearSancion(Sancion sancion) throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();	
		
		DataBase.getSession().save(SancionItem.toEntity(sancion));
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
	}

	@Override
	public void actualizarSancion(Sancion sancion) throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();	
		
		DataBase.getSession().update(DataBase.getSession().merge(SancionItem.toEntity(sancion)));
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
	}

	@Override
	public void eliminarSancion(Sancion sancion) throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();	
		
		DataBase.getSession().delete(SancionItem.toEntity(sancion));
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
	}

}
