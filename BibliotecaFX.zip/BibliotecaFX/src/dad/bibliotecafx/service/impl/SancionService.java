package dad.bibliotecafx.service.impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dad.bibliotecafx.db.DataBase;
import dad.bibliotecafx.modelo.Libro;
import dad.bibliotecafx.modelo.Prestamo;
import dad.bibliotecafx.modelo.Sancion;
import dad.bibliotecafx.service.ISancionService;
import dad.bibliotecafx.service.ServiceException;

public class SancionService implements ISancionService {

	Connection conn;

	public SancionService() {
		conn = DataBase.connect();
	}

	@Override
	public List<Sancion> listarSanciones() throws ServiceException {
		List<Sancion> sancionList = new ArrayList<Sancion>();

		String cons = "SELECT s.Cod_Libro, p.Cod_Prestamo, s.Cod_Sancion, s.Fecha_Alta, s.Fecha_Finalizacion, "
				+ "u.Cod_usuario, u.Nombre, u.Apellidos FROM sancion AS s INNER JOIN prestamo "
				+ "AS p ON s.Cod_Prestamo = p.Cod_Prestamo INNER JOIN usuario AS u ON p.Cod_usuario = u.Cod_usuario";

		try {
			PreparedStatement consulta = conn.prepareStatement(cons);

			ResultSet resultado;
			resultado = consulta.executeQuery();

			while (resultado.next()) {
				Sancion s = new Sancion();
				Libro l = new Libro();
				Prestamo p = new Prestamo();
				l.setCodigo(resultado.getInt("p.Cod_Libro"));
				p.setCodigo(resultado.getInt("p.Cod_Prestamo"));
				s.setCodigo(resultado.getInt("s.Cod_Sancion"));
				s.setFechaAlta(resultado.getDate("s.Fecha_Alta"));
				s.setFechaFinalizacion(resultado.getDate("s.Fecha_Finalizacion"));
				s.setLibro(l);
				s.setPrestamo(p);

				sancionList.add(s);
			}
			consulta.close();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new ServiceException("No se ha podido realizar la consulta de sanciones.", e);
		}

		return sancionList;
	}

	@Override
	public void crearSancion(Sancion sancion) throws ServiceException {
		String ins = "INSERT INTO sancion (Cod_Libro, Cod_Prestamo, Fecha_Alta, Fecha_Finalizacion) VALUES (?,?,?,?)";

		PreparedStatement insercion;
		try {
			insercion = conn.prepareStatement(ins);
			insercion.setInt(1, sancion.getLibro().getCodigo());
			insercion.setInt(2, sancion.getPrestamo().getCodigo());
			insercion.setDate(3, (Date) sancion.getFechaAlta());
			insercion.setDate(4, (Date) sancion.getFechaFinalizacion());
			insercion.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new ServiceException("No se ha podido realizar la inserci�n de la sanci�n.", e);
		}
	}

	@Override
	public void actualizarSancion(Sancion sancion) throws ServiceException {
		String upd = "UPDATE sancion SET Cod_Libro = ?, Cod_Prestamo = ?, Fecha_Alta = ? , Fecha_Finalizacion = ? "
				+ "WHERE Cod_Sancion = ?";

		try {
			PreparedStatement update = conn.prepareStatement(upd);
			update.setInt(1, sancion.getLibro().getCodigo());
			update.setInt(2, sancion.getPrestamo().getCodigo());
			update.setDate(3, (Date) sancion.getFechaAlta());
			update.setDate(4, (Date) sancion.getFechaFinalizacion());
			update.setInt(5, sancion.getCodigo());
			update.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new ServiceException("No se ha podido actualizar la sanci�n.", e);
		}
	}

	@Override
	public void eliminarSancion(Integer id) throws ServiceException {
		String del = "DELETE FROM sancion WHERE Cod_Sancion = ?";

		try {
			PreparedStatement eliminar = conn.prepareStatement(del);
			eliminar.setInt(1, id);
			eliminar.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new ServiceException("No se ha podido eliminar la sanci�n.", e);
		}
	}

}
