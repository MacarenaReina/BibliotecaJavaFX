package dad.bibliotecafx.service.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import dad.bibliotecafx.modelo.Sancion;
import dad.bibliotecafx.service.ISancionService;
import dad.bibliotecafx.service.ServiceException;
import dad.bibliotecafx.utils.HibernateUtil;

public class SancionService implements ISancionService {

	private Session sesion;

	@SuppressWarnings("unchecked")
	@Override
	public List<Sancion> listarSanciones() throws ServiceException {		
		sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();		
		Query consultaSanciones = sesion.createQuery("FROM Sancion");
		List<Sancion> sancionList = consultaSanciones.list();
		sesion.getTransaction().commit();
		sesion.close();		
		return sancionList;		
	}

	@Override
	public void crearSancion(Sancion sancion) throws ServiceException {
		sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();	
		sesion.save(sancion);	
		sesion.getTransaction().commit();
		sesion.close();	
	}

	@Override
	public void actualizarSancion(Sancion sancion) throws ServiceException {
		sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();	
		sesion.update(sancion);
		sesion.getTransaction().commit();
		sesion.close();	
	}

	@Override
	public void eliminarSancion(Sancion sancion) throws ServiceException {
		sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();	
		sesion.delete(sancion);
		sesion.getTransaction().commit();
		sesion.close();	
	}

}
