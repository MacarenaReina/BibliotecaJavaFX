package dad.bibliotecafx.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dad.bibliotecafx.db.DataBase;
import dad.bibliotecafx.modelo.Editorial;
import dad.bibliotecafx.service.IEditorialService;
import dad.bibliotecafx.service.ServiceException;

public class EditorialService implements IEditorialService {

	Connection conn;
	public EditorialService(){
		conn = DataBase.connect();
	}
	
	@Override
	public List<Editorial> listarEditoriales() throws ServiceException {
		List<Editorial> editorialList = new ArrayList<Editorial>();
		
		String cons = "SELECT * FROM editorial";
		
		try {
			PreparedStatement consulta = conn.prepareStatement(cons);
			
			ResultSet resultado;
			resultado = consulta.executeQuery();
			
			while (resultado.next()) {
				Editorial e = new Editorial();
				e.setCodigo(resultado.getInt("Cod_Editorial"));
				e.setNombre(resultado.getString("Nombre"));				
				editorialList.add(e);
			}
			consulta.close();			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new ServiceException("No se ha podido realizar la consulta de editoriales.", e);
		}
		
		return editorialList;
	}

	@Override
	public void crearEditorial(Editorial editorial) throws ServiceException {
		String ins = "INSERT INTO editorial (Nombre) VALUES (?)";
		
		PreparedStatement insercion;
		try {
			insercion = conn.prepareStatement(ins);
			insercion.setString(1, editorial.getNombre());			
			insercion.executeUpdate();			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new ServiceException("No se ha podido realizar la inserci�n de la editorial.", e);
		}		
	}

	@Override
	public void actualizarEditorial(Editorial editorial) throws ServiceException {
		String upd = "UPDATE editorial SET Nombre = ? WHERE Cod_Editorial = ?";
		
		try {
			PreparedStatement update = conn.prepareStatement(upd);
			update.setString(1, editorial.getNombre());
			update.setInt(2, editorial.getCodigo());
			update.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new ServiceException("No se ha podido actualizar la editorial.", e);
		}		
	}

	@Override
	public void eliminarEditorial(Integer id) throws ServiceException {
		String del = "DELETE FROM editorial WHERE Cod_Editorial = ?";
		
		try {
			PreparedStatement eliminar = conn.prepareStatement(del);
			eliminar.setInt(1, id);
			eliminar.executeUpdate();			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new ServiceException("No se ha podido eliminar la editorial.", e);
		}
	}

}
