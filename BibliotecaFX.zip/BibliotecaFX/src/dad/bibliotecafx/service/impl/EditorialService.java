package dad.bibliotecafx.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;

import dad.bibliotecafx.db.DataBase;
import dad.bibliotecafx.modelo.Editorial;
import dad.bibliotecafx.service.IEditorialService;
import dad.bibliotecafx.service.ServiceException;
import dad.bibliotecafx.service.entidades.EditorialEntity;
import dad.bibliotecafx.service.items.EditorialItem;

public class EditorialService implements IEditorialService {

	
	@SuppressWarnings("unchecked")
	@Override
	public List<Editorial> listarEditoriales() throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();		
		Query consultaEditoriales = DataBase.getSession().createQuery("FROM Editorial");
		List<EditorialEntity> editorialList = consultaEditoriales.list();
		
		List<Editorial> editoriales = new ArrayList<Editorial>();
		
		for (EditorialEntity e : editorialList) {
			editoriales.add(EditorialItem.toModel(e));
		}
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
		return editoriales;
	}

	@Override
	public void crearEditorial(Editorial editorial) throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();	
		
		DataBase.getSession().save(EditorialItem.toEntity(editorial));	
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
	}

	@Override
	public void actualizarEditorial(Editorial editorial) throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();	
		
		DataBase.getSession().update(DataBase.getSession().merge(EditorialItem.toEntity(editorial)));	
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
	}

	@Override
	public void eliminarEditorial(Editorial editorial) throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();	
		
		DataBase.getSession().delete(EditorialItem.toEntity(editorial));	
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
	}

}
