package dad.bibliotecafx.service.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import dad.bibliotecafx.modelo.Editorial;
import dad.bibliotecafx.service.IEditorialService;
import dad.bibliotecafx.service.ServiceException;
import dad.bibliotecafx.utils.HibernateUtil;

public class EditorialService implements IEditorialService {

	private Session sesion;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Editorial> listarEditoriales() throws ServiceException {
		sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();		
		Query consultaEditoriales = sesion.createQuery("FROM Editorial");
		List<Editorial> editorialList = consultaEditoriales.list();
		sesion.getTransaction().commit();
		sesion.close();		
		return editorialList;
	}

	@Override
	public void crearEditorial(Editorial editorial) throws ServiceException {
		sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();	
		sesion.save(editorial);	
		sesion.getTransaction().commit();
		sesion.close();		
	}

	@Override
	public void actualizarEditorial(Editorial editorial) throws ServiceException {
		sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();	
		sesion.update(editorial);
		sesion.getTransaction().commit();
		sesion.close();	
	}

	@Override
	public void eliminarEditorial(Editorial editorial) throws ServiceException {
		sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();	
		sesion.delete(editorial);
		sesion.getTransaction().commit();
		sesion.close();	
	}

}
