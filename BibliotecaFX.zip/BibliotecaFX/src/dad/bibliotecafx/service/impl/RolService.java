package dad.bibliotecafx.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;

import dad.bibliotecafx.db.DataBase;
import dad.bibliotecafx.modelo.Rol;
import dad.bibliotecafx.modelo.RolUsuario;
import dad.bibliotecafx.service.IRolService;
import dad.bibliotecafx.service.ServiceException;
import dad.bibliotecafx.service.entidades.RolEntity;
import dad.bibliotecafx.service.items.RolItem;
import dad.bibliotecafx.service.items.RolUsuarioItem;

public class RolService implements IRolService {

	@SuppressWarnings("unchecked")
	@Override
	public List<Rol> listarRoles() throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();		
		Query consultaRoles = DataBase.getSession().createQuery("FROM Rol");
		List<RolEntity> rolList = consultaRoles.list();
		
		List<Rol> roles = new ArrayList<Rol>();
		
		for (RolEntity r : rolList) {
			roles.add(RolItem.toModel(r));
		}		
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
		return roles;
	}

	@Override
	public void crearRol(Rol rol) throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();	
		
		DataBase.getSession().save(RolItem.toEntity(rol));

		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
	}

	@Override
	public void actualizarRol(Rol rol) throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();	
		
		DataBase.getSession().update(DataBase.getSession().merge(RolItem.toEntity(rol)));

		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
	}

	@Override
	public void eliminarRol(Rol rol) throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();	
		
		DataBase.getSession().delete(RolItem.toEntity(rol));
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
	}

	@Override
	public void asignarRol(RolUsuario rolUsuario) throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();	
		
		DataBase.getSession().save(RolUsuarioItem.toEntity(rolUsuario));
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
	}

	@Override
	public void actualizarRolUsuario(RolUsuario rolUsuario) throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();	
		
		DataBase.getSession().update(DataBase.getSession().merge(RolUsuarioItem.toEntity(rolUsuario)));
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
	}

	@Override
	public void eliminarRolUsuario(RolUsuario rolUsuario) throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();	
		
		DataBase.getSession().delete(RolUsuarioItem.toEntity(rolUsuario));
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
	}

}
