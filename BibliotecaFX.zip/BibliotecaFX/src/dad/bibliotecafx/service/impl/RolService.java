package dad.bibliotecafx.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dad.bibliotecafx.db.DataBase;
import dad.bibliotecafx.modelo.Rol;
import dad.bibliotecafx.modelo.Usuario;
import dad.bibliotecafx.service.IRolService;
import dad.bibliotecafx.service.ServiceException;

public class RolService implements IRolService {

	Connection conn;

	public RolService() {
		conn = DataBase.connect();
	}

	@Override
	public List<Rol> listarRoles() throws ServiceException {
		List<Rol> rolList = new ArrayList<Rol>();

		String cons = "SELECT * FROM rol";

		try {
			PreparedStatement consulta = conn.prepareStatement(cons);

			ResultSet resultado;
			resultado = consulta.executeQuery();

			while (resultado.next()) {
				Rol r = new Rol();
				r.setCodigo(resultado.getInt("Cod_Permiso"));
				r.setTipo(resultado.getString("Tipo"));
				rolList.add(r);
			}
			consulta.close();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new ServiceException("No se ha podido realizar la consulta de roles.", e);
		}

		return rolList;
	}

	@Override
	public void crearRol(Rol rol) throws ServiceException {
		String ins = "INSERT INTO rol ( Tipo) VALUES (?)";

		PreparedStatement insercion;
		try {
			insercion = conn.prepareStatement(ins);
			insercion.setString(1, rol.getTipo());
			insercion.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new ServiceException("No se ha podido realizar la inserci�n del rol.", e);
		}
	}

	@Override
	public void actualizarRol(Rol rol) throws ServiceException {
		String upd = "UPDATE rol SET Tipo = ? WHERE Cod_Permiso = ?";

		try {
			PreparedStatement update = conn.prepareStatement(upd);
			update.setString(1, rol.getTipo());
			update.setInt(2, rol.getCodigo());
			update.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new ServiceException("No se ha podido actualizar el rol.", e);
		}
	}

	@Override
	public void eliminarRol(Integer id) throws ServiceException {
		String del = "DELETE FROM rol WHERE Cod_Permiso = ?";

		try {
			PreparedStatement eliminar = conn.prepareStatement(del);
			eliminar.setInt(1, id);
			eliminar.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new ServiceException("No se ha podido eliminar el rol.", e);
		}
	}

	@Override
	public void asignarRol(Usuario usuario, Rol rol) throws ServiceException {
		String ins = "INSERT INTO roles_usuarios (Cod_Permiso, Cod_usuario, Activado) VALUES (?,?,?)";

		PreparedStatement insercion;
		try {
			insercion = conn.prepareStatement(ins);
			insercion.setInt(1, rol.getCodigo());
			insercion.setInt(2, usuario.getCodigo());
			insercion.setBoolean(3, usuario.getActivado());
			insercion.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new ServiceException("No se ha podido asignar el rol al usuario.", e);
		}
	}

	@Override
	public void actualizarRolUsuario(Usuario usuario, Rol rol) throws ServiceException {
		String upd = "UPDATE roles_usuarios SET Cod_Permiso = ?, Activado = ? WHERE Cod_usuario = ?";
		try {
			PreparedStatement update = conn.prepareStatement(upd);
			update.setInt(1, rol.getCodigo());
			update.setBoolean(2, usuario.getActivado());
			update.setInt(3, usuario.getCodigo());
			update.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new ServiceException("No se ha podido actualizar el rol al usuario.", e);
		}
	}

	@Override
	public void eliminarRolUsuario(Integer id) throws ServiceException {
		String del = "DELETE FROM roles_usuarios WHERE Cod_Usuario = ?";

		try {
			PreparedStatement eliminar = conn.prepareStatement(del);
			eliminar.setInt(1, id);
			eliminar.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new ServiceException("No se ha podido eliminar la editorial.", e);
		}
	}

}
