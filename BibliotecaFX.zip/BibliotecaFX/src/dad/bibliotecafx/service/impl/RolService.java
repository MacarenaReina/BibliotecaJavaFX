package dad.bibliotecafx.service.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import dad.bibliotecafx.modelo.Rol;
import dad.bibliotecafx.modelo.Rol_Usuario;
import dad.bibliotecafx.service.IRolService;
import dad.bibliotecafx.service.ServiceException;
import dad.bibliotecafx.utils.HibernateUtil;

public class RolService implements IRolService {
	
	private Session sesion;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Rol> listarRoles() throws ServiceException {
		sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();		
		Query consultaRoles = sesion.createQuery("FROM Rol");
		List<Rol> rolList = consultaRoles.list();
		sesion.getTransaction().commit();
		sesion.close();		
		return rolList;
	}

	@Override
	public void crearRol(Rol rol) throws ServiceException {
		sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();	
		sesion.save(rol);	
		sesion.getTransaction().commit();
		sesion.close();	
	}

	@Override
	public void actualizarRol(Rol rol) throws ServiceException {
		sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();	
		sesion.update(rol);
		sesion.getTransaction().commit();
		sesion.close();	
	}

	@Override
	public void eliminarRol(Rol rol) throws ServiceException {
		sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();	
		sesion.delete(rol);
		sesion.getTransaction().commit();
		sesion.close();	
	}

	@Override
	public void asignarRol(Rol_Usuario ru) throws ServiceException {
		sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();	
		sesion.save(ru);
		sesion.getTransaction().commit();
		sesion.close();	
	}

	@Override
	public void actualizarRolUsuario(Rol_Usuario ru) throws ServiceException {
		sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();	
		sesion.update(ru);
		sesion.getTransaction().commit();
		sesion.close();
	}

	@Override
	public void eliminarRolUsuario(Rol_Usuario ru) throws ServiceException {
		sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();	
		sesion.delete(ru);
		sesion.getTransaction().commit();
		sesion.close();
	}

}
