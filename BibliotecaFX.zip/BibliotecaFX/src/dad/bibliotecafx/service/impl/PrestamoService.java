package dad.bibliotecafx.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;

import dad.bibliotecafx.db.DataBase;
import dad.bibliotecafx.modelo.Prestamo;
import dad.bibliotecafx.service.IPrestamoService;
import dad.bibliotecafx.service.ServiceException;
import dad.bibliotecafx.service.entidades.PrestamoEntity;
import dad.bibliotecafx.service.items.PrestamoItem;

public class PrestamoService implements IPrestamoService {

	@SuppressWarnings("unchecked")
	@Override
	public List<Prestamo> listarPrestamos() throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();		
		Query consultaPrestamos = DataBase.getSession().createQuery("FROM Prestamo");
		List<PrestamoEntity> prestamosList = consultaPrestamos.list();
		
		List<Prestamo> prestamos = new ArrayList<Prestamo>();
		for (PrestamoEntity p : prestamosList) {
			prestamos.add(PrestamoItem.toModel(p));
		}		
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
		return prestamos;
	}

	@Override
	public void crearPrestamo(Prestamo prestamo) throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();	
		
		DataBase.getSession().save(PrestamoItem.toEntity(prestamo));
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();	
//		DataBase.getSession().close();
	}

	@Override
	public void actualizarPrestamo(Prestamo prestamo) throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();	
		
		DataBase.getSession().update(DataBase.getSession().merge(PrestamoItem.toEntity(prestamo)));
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
	}

	@Override
	public void eliminarPrestamo(Prestamo prestamo) throws ServiceException {
//		DataBase.connect();
		DataBase.getSession().beginTransaction();	
		
		DataBase.getSession().delete(PrestamoItem.toEntity(prestamo));
		
		DataBase.getSession().getTransaction().commit();
		DataBase.getSession().clear();
//		DataBase.getSession().close();
	}

}
